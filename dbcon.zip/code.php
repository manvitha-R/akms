<?php
session_start();
include('dbcon.php');


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

function sendemail_verify($name,$email,$verify_token)
{
   
    // require ("PHPMailer/PHPMailer.php");
	// require ("PHPMailer/SMTP.php");
	// require ("PHPMailer/Exception.php");

	$mail = new PHPMailer(true);

	try {
		//Server settings

		$mail->isSMTP();                                            //Send using SMTP
		$mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
		$mail->SMTPAuth   = true;                                   //Enable SMTP authentication
		$mail->Username   = 'amruthss19@gmail.com';                     //SMTP username
		$mail->Password   = 'vmecueyjvjyffukp';                               //SMTP password
		$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
		$mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
	
		//Recipients
		$mail->setFrom('amruthss19@gmail.com', 'AKMS');
		$mail->addAddress($email);     //Add a recipient
		
		//Attachments
		// $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
		// $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name
	
		//Content
		$mail->isHTML(true);                                  //Set email format to HTML
		$mail->Subject = 'Email Verification from AKMS';
		// $mail->Body    = "Thanks for registration!
		//   Click the link below to verify the email address
		//   <a herf='http://localhost/form1/verify.php?email=$email&v_code=$v_code'>Verify</a>";
		  $mail->Body ="
      <h2>Hello</h2>
	  <h3>Thanks For Registration!!!</h3>
      <h4>Click the link below to verify the email address..</h4>
      <br/><br/>
      <a href='http://localhost/Akm/verify-emails.php?token=$verify_token'> Click Me </a>
      ";
 
		$mail->send();
		echo 'Message has been sent';
	} catch (Exception $e) {
		echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
	}

}

if(isset($_POST['register_btn']))
{
    $name = $_POST['name'];  
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $verify_token = md5(rand());
 

    // Email Exists or not
    $check_email_query = "SELECT email FROM register WHERE email='$email' LIMIT 1";
    $check_email_query_run = mysqli_query($con, $check_email_query);

    if(mysqli_num_rows($check_email_query_run) > 0 )
    {
        $_SESSION['status'] = "Email Id already Exists";
        header("Location: register.php");
    }
    else
    {
        // Insert User / Registered User Data
        $query = "INSERT INTO register (name,email,phone,password,verify_token	) VALUES ('$name','$email','$phone','$password','$verify_token')";
        $query_run = mysqli_query($con, $query);

        if($query_run)
        {
            sendemail_verify("$name","$email","$verify_token");
            $_SESSION['status'] = "Register Successfull..! Please verify your Email Address";
            header("Location: register.php");
        }
        else
        {
            $_SESSION['status'] = "Registration Failed";
            header("Location: register.php");
        }
    }
}
?>