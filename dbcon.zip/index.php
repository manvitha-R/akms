<?php 
$page_title = "Home Page";
include('includes/header.php');
include('navbar.php');
?>


<div class="py-5">
    <div class="container text-center">
        <div class="row">
            <div class="col-md-12">
            <h4>Login</h4>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>